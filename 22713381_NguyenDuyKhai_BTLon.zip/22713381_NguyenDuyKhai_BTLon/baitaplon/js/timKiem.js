var arrXM = [
    {
                name: "Air Blade 2020",
                image: "../img/xm1.jpg",
                originalPrice: 43190182 ,
                category: "Air Blade 2020",
                specs: [
                    "•Khối Lượng: 113 kg",
                    "•Màu Sắc: Xanh Xám Đen",
                    "•Độ Cao Yên: 775mm",
                    "• Dung Tích Bình Xăng: 4,4 lít",
                    "•Dài Rộng Cao: 1.887 x 687 x 1.092 mm",
                    "•Hộp Số: Vô Cấp "
        ]
    },
    {
            name: "Air Blade 125 phiên bản Tiêu Chuẩn",
            image: "../img/xm2.png",
            originalPrice: 43190182 ,
            category: "Air Blade 2020",
            specs: [
                "•Khối Lượng: 113 kg",
                "•Màu Sắc: Đỏ Đen",
                "•Độ Cao Yên: 775mm",
                "• Dung Tích Bình Xăng: 4,4 lít",
                "•Dài Rộng Cao: 1.887 x 687 x 1.092 mm",
                "•Hộp Số: Vô Cấp "
            ]
    },
    {
        name: "Lead 125",
        image: "../img/xm3.jpg",
        originalPrice: 42797455 ,
        category: "Lead 125",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng Sữa",
            "•Độ Cao Yên: 760mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:  1.844mm x 680mm x 1.130mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "SH 350i",
        image: "../img/xm5.jpg",
        originalPrice:150990000 ,
        category: "Lead 125",
        specs: [
            "•Khối Lượng: 172 kg",
            "•Màu Sắc: Đỏ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 9,3 lít",
            "•Dài Rộng Cao:  2.160mm x 743mm x 1.162mm",
            "•Hộp Số:  Biến thiên vô cấp "
        ]
    },
    {
        name: "SHmode 125cc",
        image: "../img/xm6.jpg",
        originalPrice: 57132000 ,
        category: "SHmode 125cc",
        specs: [
            "•Khối Lượng: 116 kg",
            "•Màu Sắc: Trắng ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Winner V3",
        image: "../img/xm7.jpg",
        originalPrice: 50060000 ,
        category: "Winner V3",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,5 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Vison 2021",
        image: "../img/xm8.png",
        originalPrice: 30990000 ,
        category: "Vison 2021",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
        "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "EXCITER 155 VVA",
        image: "../img/xm9.jpg",
        originalPrice: 30990000 ,
        category: "EXCITER 155 VVA",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "NVX 155 VVA",
        image: "../img/xm9.jpg",
        originalPrice: 30990000 ,
        category: "NVX 155 VVA",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Sirius 2022",
        image: "../img/xm10.jpg",
        originalPrice: 54000000 ,
        category: "Sirius 2022",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Exciter 2018",
        image: "../img/xm11.jpg",
        originalPrice: 30990000 ,
        category: "Exciter 2018",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Jannus 2022",
        image: "../img/xm12.jpg",
        originalPrice: 30990000 ,
        category: "Jannus 2022",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Đỏ Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Nouvo4 LX",
        image: "../img/xm13.jpg",
        originalPrice: 30990000 ,
        category: "Nouvo4 LX",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Grande 2017",
        image: "../img/xm14jpg.jpg",
        originalPrice: 30990000 ,
        category: "Grande 2017",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Sirius 2010",
        image: "../img/xm15.png",
        originalPrice: 30990000 ,
        category: "Sirius 2010",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
];
var arrPK = [
    {
        name: "Bánh Xe",
        image: "../img/pk1.jpg",
        originalPrice: 500000 ,
        category: "Bánh Xe",
    },
    {
        name: "Bạc Đạn-Gon",
        image: "../img/pk2.jpg",
        originalPrice: 150000 ,
        category: "Bạc Đạn-Gon",
    },
    {
        name: "Bình Ắc Quy",
        image: "../img/pk3.jpg",
        originalPrice: 550000 ,
        category: "Bình Ắc Quy",
    },
    {
        name: "Bộ Đầu Đèn",
        image: "../img/pk4.png",
        originalPrice: 360000 ,
        category: "Bộ Đầu Đèn",
    },
    {
        name: "Bộ Lửa",
        image: "../img/pk5.jpg",
        originalPrice: 200000 ,
        category: "Bộ Lửa",
    },
    {
        name: "Bình Xăng Con",
        image: "../img/pk6.png",
        originalPrice: 1000000 ,
        category: "Bình Xăng Con",
    },
    {
        name: "Bộ Công Tắc",
        image: "../img/pk7.jpg",
        originalPrice: 150000 ,
        category: "Bộ Công Tắc",
    },
    {
        name: "Bộ Nắp Xe",
        image: "../img/pk8.png",
        originalPrice: 70000 ,
        category: "Bộ Nắp Xe",
    },
    {
        name: "Bộ Nồi",
        image: "../img/pk9.jpg",
        originalPrice: 300000 ,
        category: "Bộ Nồi",
    },
    {
        name: "Bộ Thắng",
        image: "../img/pk10.png",
        originalPrice: 100000 ,
        category: "Bộ Thắng",
    },
    {
        name: "Bugi Xe Máy",
        image: "../img/pk11.png",
        originalPrice: 150000 ,
        category: "Bugi Xe Máy",
    },
    {
        name: "Bơm Nhớt-Xăng",
        image: "../img/pk12.jpg",
        originalPrice: 150000 ,
        category: "Bơm Nhớt-Xăng",
    },
    {
        name: "Gương Xe Máy",
        image: "../img/pk13.png",
        originalPrice: 30000 ,
        category: "Gương Xe Máy",
    },
    {
        name: "Giảm Xóc",
        image: "../img/pk14.jpg",
        originalPrice: 250000 ,
        category: "Giảm Xóc",
    },
    {
        name: "Đĩa Phanh Xe",
        image: "../img/pk15.png",
        originalPrice: 150000 ,
        category: "Đĩa Phanh Xe",
    },
];

function showProductsByCategory2(category) {
    const productsContainer = document.getElementById("products");
    productsContainer.innerHTML = "";

    const productsToShow = []; 

    arrDT.forEach((item) => {
        if (item.category2 === category) {
            productsContainer.innerHTML +=
            `
            <img src=${item.image} alt="" >
            <div style="margin-left: 5px;font-size: 8px;">
                Giảm giá mạnh <br>
                ${item.name} <br>
                <b style="text-decoration-line:line-through;">${item.discountedPrice}đ</b><span>-${item.discountPercent}%</span><br>
                <b style="color: red;">${item.originalPrice}</b>
                <ol style="list-style: circle;margin-left: -20px;">
                    <li>${specs[0]}</li>
                    <li>${space[1]}</li>
                    <li>${space[2]}</li>
                    <li>${space[3]}</li>
                    <li>${space[4]}</li>
                    <li>${space[5]}</li>
                </ol>
            </div>
            `
        }
    });

    
    }
