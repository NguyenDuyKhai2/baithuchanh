var arrXM = [
    {
                name: "Air Blade 2020",
                image: "../img/xm1.jpg",
                originalPrice: 43190182 ,
                category: "Air Blade 2020",
                specs: [
                    "•Khối Lượng: 113 kg",
                    "•Màu Sắc: Xanh Xám Đen",
                    "•Độ Cao Yên: 775mm",
                    "• Dung Tích Bình Xăng: 4,4 lít",
                    "•Dài Rộng Cao: 1.887 x 687 x 1.092 mm",
                    "•Hộp Số: Vô Cấp "
        ]
    },
    {
            name: "Air Blade 125 phiên bản Tiêu Chuẩn",
            image: "../img/xm2.png",
            originalPrice: 43190182 ,
            category: "Air Blade 2020",
            specs: [
                "•Khối Lượng: 113 kg",
                "•Màu Sắc: Đỏ Đen",
                "•Độ Cao Yên: 775mm",
                "• Dung Tích Bình Xăng: 4,4 lít",
                "•Dài Rộng Cao: 1.887 x 687 x 1.092 mm",
                "•Hộp Số: Vô Cấp "
            ]
    },
    {
        name: "Lead 125",
        image: "../img/xm3.jpg",
        originalPrice: 42797455 ,
        category: "Lead 125",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng Sữa",
            "•Độ Cao Yên: 760mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:  1.844mm x 680mm x 1.130mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "SH 350i",
        image: "../img/xm5.jpg",
        originalPrice:150990000 ,
        category: "Lead 125",
        specs: [
            "•Khối Lượng: 172 kg",
            "•Màu Sắc: Đỏ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 9,3 lít",
            "•Dài Rộng Cao:  2.160mm x 743mm x 1.162mm",
            "•Hộp Số:  Biến thiên vô cấp "
        ]
    },
    {
        name: "SHmode 125cc",
        image: "../img/xm6.jpg",
        originalPrice: 57132000 ,
        category: "SHmode 125cc",
        specs: [
            "•Khối Lượng: 116 kg",
            "•Màu Sắc: Trắng ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Winner V3",
        image: "../img/xm7.jpg",
        originalPrice: 50060000 ,
        category: "Winner V3",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,5 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Vison 2021",
        image: "../img/xm8.png",
        originalPrice: 30990000 ,
        category: "Vison 2021",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
        "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "EXCITER 155 VVA",
        image: "../img/xm9.jpg",
        originalPrice: 30990000 ,
        category: "EXCITER 155 VVA",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887mm x 687mm x 1.092mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "NVX 155 VVA",
        image: "../img/xm9.jpg",
        originalPrice: 30990000 ,
        category: "NVX 155 VVA",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Sirius 2022",
        image: "../img/xm10.jpg",
        originalPrice: 54000000 ,
        category: "Sirius 2022",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Exciter 2018",
        image: "../img/xm11.jpg",
        originalPrice: 30990000 ,
        category: "Exciter 2018",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Jannus 2022",
        image: "../img/xm12.jpg",
        originalPrice: 30990000 ,
        category: "Jannus 2022",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Đỏ Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Nouvo4 LX",
        image: "../img/xm13.jpg",
        originalPrice: 30990000 ,
        category: "Nouvo4 LX",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Trắng ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Grande 2017",
        image: "../img/xm14jpg.jpg",
        originalPrice: 30990000 ,
        category: "Grande 2017",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
    {
        name: "Sirius 2010",
        image: "../img/xm15.png",
        originalPrice: 30990000 ,
        category: "Sirius 2010",
        specs: [
            "•Khối Lượng: 113 kg",
            "•Màu Sắc: Xanh Xám Đen ",
            "•Độ Cao Yên: 775mm",
            "• Dung Tích Bình Xăng: 4,4 lít",
            "•Dài Rộng Cao:   1.887 x 687 x 1.092 mm",
            "•Hộp Số: Vô Cấp "
        ]
    },
];
var arrPK = [
    {
        name: "Bánh Xe",
        image: "../img/pk1.jpg",
        originalPrice: 500000 ,
        category: "Bánh Xe",
    },
    {
        name: "Bạc Đạn-Gon",
        image: "../img/pk2.jpg",
        originalPrice: 150000 ,
        category: "Bạc Đạn-Gon",
    },
    {
        name: "Bình Ắc Quy",
        image: "../img/pk3.jpg",
        originalPrice: 550000 ,
        category: "Bình Ắc Quy",
    },
    {
        name: "Bộ Đầu Đèn",
        image: "../img/pk4.png",
        originalPrice: 360000 ,
        category: "Bộ Đầu Đèn",
    },
    {
        name: "Bộ Lửa",
        image: "../img/pk5.jpg",
        originalPrice: 200000 ,
        category: "Bộ Lửa",
    },
    {
        name: "Bình Xăng Con",
        image: "../img/pk6.png",
        originalPrice: 1000000 ,
        category: "Bình Xăng Con",
    },
    {
        name: "Bộ Công Tắc",
        image: "../img/pk7.jpg",
        originalPrice: 150000 ,
        category: "Bộ Công Tắc",
    },
    {
        name: "Bộ Nắp Xe",
        image: "../img/pk8.png",
        originalPrice: 70000 ,
        category: "Bộ Nắp Xe",
    },
    {
        name: "Bộ Nồi",
        image: "../img/pk9.jpg",
        originalPrice: 300000 ,
        category: "Bộ Nồi",
    },
    {
        name: "Bộ Thắng",
        image: "../img/pk10.png",
        originalPrice: 100000 ,
        category: "Bộ Thắng",
    },
    {
        name: "Bugi Xe Máy",
        image: "../img/pk11.png",
        originalPrice: 150000 ,
        category: "Bugi Xe Máy",
    },
    {
        name: "Bơm Nhớt-Xăng",
        image: "../img/pk12.jpg",
        originalPrice: 150000 ,
        category: "Bơm Nhớt-Xăng",
    },
    {
        name: "Gương Xe Máy",
        image: "../img/pk13.png",
        originalPrice: 30000 ,
        category: "Gương Xe Máy",
    },
    {
        name: "Giảm Xóc",
        image: "../img/pk14.jpg",
        originalPrice: 250000 ,
        category: "Giảm Xóc",
    },
    {
        name: "Đĩa Phanh Xe",
        image: "../img/pk15.png",
        originalPrice: 150000 ,
        category: "Đĩa Phanh Xe",
    },
];
// var productsContainer = document.getElementById('products');
// productsContainer.innerHTML = '';

// var productsRow;
// var count = 0;

// arrDT.forEach(item => {
//     if (count % 5 === 0) {
//         productsRow = document.createElement('div');
//         productsRow.classList.add('row');
//         productsRow.classList.add('justify-content-center');
//         productsContainer.appendChild(productsRow);
//     }

//     var productDiv = createProductDiv(item);
//     productsRow.appendChild(productDiv);

//     count++;
// });

// var searchInput = document.querySelector('input');
// searchInput.addEventListener('keypress', function(e) {
//     if (e.key === 'Enter') {
//         let txtSearch = e.target.value.trim().toLowerCase();
//         let listProductsDOM = document.querySelectorAll('.product');

//         listProductsDOM.forEach(item => {
//             item.remove();
//         });

//         var count = 0;
//         arrDT.forEach(item => {
//             let productName = item.name.toLowerCase();
//             if (productName.includes(txtSearch)) {
//                 if (count % 5 === 0) {
//                     productsRow = document.createElement('div');
//                     productsRow.classList.add('row');
//                     productsRow.classList.add('justify-content-center');
//                     productsContainer.appendChild(productsRow);
//                 }
//                 var productDiv = createProductDiv(item);
//                 productsRow.appendChild(productDiv);
//                 count++;
//             }
//         });
//     }
// }); 

// function createProductDiv(item) {
//     var productDiv = document.createElement('div');
//     productDiv.classList.add('col-md-2');
//     productDiv.classList.add('product');

//     var imageElement = document.createElement('img');
//     imageElement.src = item.image;
//     imageElement.alt = item.name;

//     var infoDiv = document.createElement('div');
//     infoDiv.classList.add('info');

//     var nameDiv = document.createElement('div');
//     nameDiv.classList.add('name');
//     nameDiv.textContent = item.name;

//     var priceDiv = document.createElement('div');
//     priceDiv.classList.add('price');

    // const html = {};

    // arrDT.forEach(item => {
    //     const anhsec = document.querySelector('.anhsec');
    //     anhsec.innerHTML += `
    //     <img src=${item.image} alt="" >
    //     <div style="margin-left: 5px;font-size: 8px;">
    //         Giảm giá mạnh <br>
    //         ${item.name} <br>
    //         <b style="text-decoration-line:line-through;">${item.discountedPrice}đ</b><span>-${item.discountPercent}%</span><br>
    //         <b style="color: red;">${item.originalPrice}</b>
    //         <ol style="list-style: circle;margin-left: -20px;">
    //             <li>${specs[0]}</li>
    //             <li>${space[1]}</li>
    //             <li>${space[2]}</li>
    //             <li>${space[3]}</li>
    //             <li>${space[4]}</li>
    //             <li>${space[5]}</li>
    //         </ol>
    //     </div>
    //     `
    // })

//     html.innerHTML += `
//         <img src=${img} alt="" >
//         <div style="margin-left: 5px;font-size: 8px;">
//             Giảm giá mạnh <br>
//             iPhone 15 Pro Max <br>
        
//             <b style="text-decoration-line:line-through;">${price}đ</b><span>-${discount}%</span><br>
//             <b style="color: red;">30.990.000đ</b>
//             <ol style="list-style: circle;margin-left: -20px;">
//                 <li>${spac[0]}</li>
//                 <li>RAM: ${space[1]}</li>
//                 <li>Dung lượng: 256 GB</li>
//                 <li>Camera sau: Chính 48 MP & Phụ 12 MP, 12 MP</li>
//                 <li>Camera trước: 12 MP</li>
//                 <li>Pin 4422 mAh, Sạc 20 W</li>
//             </ol>
//         </div>
//     `;

//     var originalPrice = item.originalPrice.toLocaleString() + ' VND';
//     var discountedPrice = item.discountedPrice.toLocaleString() + ' VND';

//     var originalPriceElement = document.createElement('b');
//     originalPriceElement.style.textDecorationLine = 'line-through';
//     originalPriceElement.textContent = originalPrice;

//     var discountElement = document.createElement('span');
//     discountElement.textContent = '-' + item.discountPercent + '%';

//     var discountedPriceElement = document.createElement('b');
//     discountedPriceElement.style.color = 'red';
//     discountedPriceElement.textContent = discountedPrice;

//     priceDiv.appendChild(originalPriceElement);
//     priceDiv.appendChild(discountElement);
//     priceDiv.appendChild(document.createElement('br'));
//     priceDiv.appendChild(discountedPriceElement);

//     var specsList = document.createElement("ul");
//     specsList.classList.add("list-unstyled", "mb-0");
//     item.specs.forEach(function(spec) {
//         var specItem = document.createElement("li");
//         specItem.textContent = spec;
//         specsList.appendChild(specItem);
//     });

//     infoDiv.appendChild(nameDiv);
//     infoDiv.appendChild(priceDiv);
//     infoDiv.appendChild(specsList);
//     productDiv.appendChild(imageElement);
//     productDiv.appendChild(infoDiv);

//     return productDiv;
// }


//   function showProductsByCategory(category) {
//     const productsContainer = document.getElementById("products");
//     productsContainer.innerHTML = "";

//     const productsToShow = []; 

//     arrDT.forEach((item) => {
//         if (item.category === category) {
//             const productDiv = createProductDiv(item);
//             productsToShow.push(productDiv); 
//         }
//     });

//     const productsRow = document.createElement('div');
//     productsRow.classList.add('row');
//     productsRow.classList.add('justify-content-center');
    
//     productsToShow.forEach((productDiv) => {
//         productsRow.appendChild(productDiv);
//     });

//     productsContainer.appendChild(productsRow);
// }
function showProductsByCategory2(category) {
    const productsContainer = document.getElementById("products");
    productsContainer.innerHTML = "";

    const productsToShow = []; 

    arrDT.forEach((item) => {
        if (item.category2 === category) {
            productsContainer.innerHTML +=
            `
            <img src=${item.image} alt="" >
            <div style="margin-left: 5px;font-size: 8px;">
                Giảm giá mạnh <br>
                ${item.name} <br>
                <b style="text-decoration-line:line-through;">${item.discountedPrice}đ</b><span>-${item.discountPercent}%</span><br>
                <b style="color: red;">${item.originalPrice}</b>
                <ol style="list-style: circle;margin-left: -20px;">
                    <li>${specs[0]}</li>
                    <li>${space[1]}</li>
                    <li>${space[2]}</li>
                    <li>${space[3]}</li>
                    <li>${space[4]}</li>
                    <li>${space[5]}</li>
                </ol>
            </div>
            `
        }
    });

    // const productsRow = document.createElement('div');
    // productsRow.classList.add('row');
    // productsRow.classList.add('justify-content-center');
    
    // productsToShow.forEach((productDiv) => {
    //     productsRow.appendChild(productDiv);
    }
// );

//     productsContainer.appendChild(productsRow);
// }
// function showProductsByCategory3(category) {
//     const productsContainer = document.getElementById("products");
//     productsContainer.innerHTML = "";

//     const productsToShow = []; 

//     arrDT.forEach((item) => {
//         if (item.category3 === category) {
//             const productDiv = createProductDiv(item);
//             productsToShow.push(productDiv); 
//         }
//     });

//     const productsRow = document.createElement('div');
//     productsRow.classList.add('row');
//     productsRow.classList.add('justify-content-center');
    
//     productsToShow.forEach((productDiv) => {
//         productsRow.appendChild(productDiv);
//     });

//     productsContainer.appendChild(productsRow);
// }
